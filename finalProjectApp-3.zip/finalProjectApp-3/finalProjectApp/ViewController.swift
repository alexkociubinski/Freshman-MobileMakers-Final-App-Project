//
//  ViewController.swift
//  finalProjectApp
//
//  Created by period7 on 5/18/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var mealOneLabel: UITextField!
    @IBOutlet weak var mealTwoTF: UITextField!
    @IBOutlet weak var mealThreeTextField: UITextField!
    @IBOutlet weak var totalSnackTF: UITextField!
    @IBOutlet weak var totalCaloriesLabel: UILabel!
    @IBOutlet weak var goalForDayLabel: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let defaults = UserDefaults.standard
        if let mealOne = defaults.object(forKey: "mealone"), let mealTwo = defaults.object(forKey: "mealtwo"), let mealThree = defaults.object(forKey: "mealthree"), let totalSnack = defaults.object(forKey: "totalsnack"), let totalCalories = defaults.object(forKey: "totalcalories"), let goalForDay = defaults.object(forKey: "goalforday") {
            self.goalForDayLabel.text = goalForDay as? String
            self.mealOneLabel.text = mealOne as? String
            self.mealTwoTF.text = mealTwo as? String
            self.mealThreeTextField.text = mealThree as? String
            self.totalSnackTF.text = totalSnack as? String
            self.totalCaloriesLabel.text = totalCalories as? String
        }
  
    }
    @IBAction func calorieCalculateButton(_ sender: UIButton) {
        let mealOneTF = Int(mealOneLabel.text!)!
        let mealTwoTf = Int(mealTwoTF.text!)!
        let mealThreeTF = Int(mealThreeTextField.text!)!
        let totalSnackTf = Int(totalSnackTF.text!)!
        let totalCalories = (mealOneTF+(mealTwoTf)+(mealThreeTF)+(totalSnackTf))
      
    totalCaloriesLabel.text = "\(totalCalories)"
        
    
        let goalForTheDay = Int(goalForDayLabel.text!)!
        
        if goalForTheDay == totalCalories {
            imageView.image = UIImage (named: "Ripped")
        }
        
        goalForDayLabel.resignFirstResponder()
        totalSnackTF.resignFirstResponder()
        mealThreeTextField.resignFirstResponder()
        mealOneLabel.resignFirstResponder()
        mealTwoTF.resignFirstResponder()
        
        

        
    
    }
    
    @IBAction func saveButton(_ sender: Any) {
        let defaults = UserDefaults.standard
        defaults.set(self.mealOneLabel.text!, forKey: "mealone")
        defaults.set(self.mealTwoTF.text!, forKey: "mealtwo")
        defaults.set(self.mealThreeTextField.text!, forKey: "mealthree")
        defaults.set(self.totalSnackTF.text!, forKey: "totalsnack")
        defaults.set(self.totalCaloriesLabel.text!, forKey: "totalcalories")
        defaults.set(self.goalForDayLabel.text!, forKey: "goalforday")
    }
    
    @IBAction func breakfastRecipesButton(_ sender: UIButton) {
        let breakfasturl = URL(string: "https://themodernproper.com/50-best-breakfast-ideas")
        UIApplication.shared.open(breakfasturl!, options: [:], completionHandler: nil)
    }
    
    @IBAction func lunchRecipesButton(_ sender: UIButton) {
       let lunchurl = URL(string: "https://www.tastingtable.com/871191/healthy-lunch-recipes-to-supercharge-your-midday/")
        UIApplication.shared.open(lunchurl!, options: [:], completionHandler: nil)
    }
    
    @IBAction func dinnerRecipesButton(_ sender: UIButton) {
        let dinnerurl = URL(string: "https://www.eatingwell.com/gallery/7963984/summer-skillet-dinner-recipes/)")
    UIApplication.shared.open(dinnerurl!, options: [:], completionHandler: nil)
    }
    



}
